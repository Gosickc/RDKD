# global_memory.py
experience_pool = []
