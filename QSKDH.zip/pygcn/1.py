import matplotlib.pyplot as plt

# 解析日志数据
epochs = []
losses = []
map_i2t = []
map_t2i = []
best_map_i2t = []
best_map_t2i = []

with open('D:\\fuxian\\VLKD\\logs\\flikcr_128bit@5000.log', 'r') as file:
    for line in file:
        if 'Epoch [' in line and 'Loss' in line:
            epoch = int(line.split('Epoch [')[1].split('/')[0])
            loss = float(line.split('Loss: ')[1])
            epochs.append(epoch)
            losses.append(loss)
        elif 'mAP@5000 I->T' in line:
            map_i2t_value = float(line.split('mAP@5000 I->T: ')[1].split(',')[0])
            map_t2i_value = float(line.split('mAP@5000 T->I: ')[1].split(',')[0])
            map_i2t.append(map_i2t_value)
            map_t2i.append(map_t2i_value)
        elif 'Best MAP of I->T' in line:
            best_map_i2t_value = float(line.split('Best MAP of I->T: ')[1].split(',')[0])
            best_map_t2i_value = float(line.split('Best mAP of T->I: ')[1])
            best_map_i2t.append(best_map_i2t_value)
            best_map_t2i.append(best_map_t2i_value)

# 绘制损失曲线
plt.figure(figsize=(12, 6))
plt.plot(epochs, losses, label='Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss Over Epochs')
plt.legend()
plt.grid(True)
plt.show()

# 绘制mAP曲线
plt.figure(figsize=(12, 6))
plt.plot(range(len(map_i2t)), map_i2t, label='mAP I->T')
plt.plot(range(len(map_t2i)), map_t2i, label='mAP T->I')
plt.xlabel('Epoch')
plt.ylabel('mAP')
plt.title('mAP Over Epochs')
plt.legend()
plt.grid(True)
plt.show()

# 绘制最佳mAP曲线
plt.figure(figsize=(12, 6))
plt.plot(range(len(best_map_i2t)), best_map_i2t, label='Best mAP I->T')
plt.plot(range(len(best_map_t2i)), best_map_t2i, label='Best mAP T->I')
plt.xlabel('Epoch')
plt.ylabel('Best mAP')
plt.title('Best mAP Over Epochs')
plt.legend()
plt.grid(True)
plt.show()
